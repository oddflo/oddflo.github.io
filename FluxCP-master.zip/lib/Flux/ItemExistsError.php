<?php
require_once 'Flux/Error.php';

class Flux_ItemExistsError extends Flux_Error {
	
}
?>
