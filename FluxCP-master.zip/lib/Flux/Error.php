<?php
/**
 * All exceptions raised by Flux should be this or children of this base
 * exception class.
 */
class Flux_Error extends Exception {
	
}
?>
