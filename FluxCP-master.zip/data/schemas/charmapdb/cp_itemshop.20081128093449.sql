ALTER TABLE  `cp_itemshop` ADD INDEX (  `nameid` ) ;
