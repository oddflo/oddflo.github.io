ALTER TABLE `cp_txnlog` CHANGE `address_status` `address_status` VARCHAR(11) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
