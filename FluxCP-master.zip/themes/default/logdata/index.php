<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>rA Logs</h2>
<p>You may view the rAthena logs here.</p>
<p>Please select the log that you would like to view from the available menus.</p>
