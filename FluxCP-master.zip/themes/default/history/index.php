<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2><?php echo htmlspecialchars(Flux::message('HistoryIndexHeading')) ?></h2>
<p><?php echo htmlspecialchars(Flux::message('HistoryIndexInfo')) ?></p>
<p><?php echo htmlspecialchars(Flux::message('HistoryIndexInfo2')) ?></p>
