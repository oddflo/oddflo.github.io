<?php
return array(
	'HelloWorld'       => '안녕하세요!',
	'HelloInfoText'    => '현제보고계시는건 샘플 애드온 프로그램입니다!',
	'HelloVersionText' => '지금 사용하고계시는 플럭스 버젼은 %s입니다.'
);
?>
