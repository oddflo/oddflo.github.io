<?php
return array(
	'MenuItems' => array(
		//'Hello World' => array('module' => 'helloworld')
	)
)
?>
