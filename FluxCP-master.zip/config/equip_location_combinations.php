<?php
return array(
	'location_left_hand/location_right_hand'	=> 'Two-Handed',
	'location_head_low/location_head_mid/location_head_top'		=> 'Upper/Mid/Lower Headgear',
	'location_head_mid/location_head_top'		=> 'Upper/Mid Headgear',
	'location_head_top/location_head_low'		=> 'Upper/Lower Headgear',
	'location_head_low/location_head_mid'		=> 'Mid/Lower Headgear',
	'location_head_low/location_head_top'		=> 'Upper/Lower Headgear',
	'location_costume_head_mid/location_costume_head_top'		=> 'Costume Upper/Mid Headgear',
	'location_costume_head_low/location_costume_head_top'		=> 'Costume Upper/Lower Headgear',
	'location_costume_head_low/location_costume_head_mid'		=> 'Costume Mid/Lower Headgear',
	'location_costume_head_low/location_costume_head_mid/location_costume_head_top'	=> 'Costume Upper/Mid/Lower Headgear',
	'location_left_accessory/location_right_accessory'	=> 'Accessory Left/Right',
	'location_armor/location_garment/location_head_low/location_head_mid/location_head_top/location_left_accessory/location_left_hand/location_right_accessory/location_right_hand/location_shoes'	=> 'All equip',
)
?>
