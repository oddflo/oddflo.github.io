<?php
// rA monster races.
return array(
	 'Formless'		=> 'Formless',
	 'Undead'		=> 'Undead',
	 'Brute'		=> 'Brute',
	 'Plant'		=> 'Plant',
	 'Insect'		=> 'Insect',
	 'Fish'			=> 'Fish',
	 'Demon'		=> 'Demon',
	 'Demihuman'	=> 'Demi-Human',
	 'Angel'		=> 'Angel',
	 'Dragon'		=> 'Dragon'
)
?>
