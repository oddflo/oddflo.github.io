<?php
return array(
	0	=>	// Default job list
	array(
		'job_all' => 'All jobs',
		'job_novice' => 'Novice',
		'job_supernovice' => 'Super novice',
		'job_swordman' => 'Swordman',
		'job_mage' => 'Mage',
		'job_archer' => 'Archer',
		'job_merchant' => 'Merchant',
		'job_thief' => 'Thief',
		'job_knight' => 'Knight',
		'job_priest' => 'Priest',
		'job_wizard' => 'Wizard',
		'job_blacksmith' => 'Blacksmith',
		'job_hunter' => 'Hunter',
		'job_assassin' => 'Assassin',
		'job_crusader' => 'Crusader',
		'job_monk' => 'Monk',
		'job_sage' => 'Sage',
		'job_rogue' => 'Rogue',
		'job_alchemist' => 'Alchemist',
		'job_barddancer' => 'Bard / Dancer',
		'job_taekwon' => 'Taekwon',
		'job_stargladiator' => 'Star Gladiator',
		'job_soullinker' => 'Soul Linker',
		'job_gunslinger' => 'Gunslinger',
		'job_ninja' => 'Ninja',
	),
	1	=>	// Renewal job list
	array(
		'job_kagerouoboro' => 'Kagerou / Oboro',
		'job_rebellion' => 'Rebellion',
		'job_summoner' => 'Summoner'
	)
)
?>
