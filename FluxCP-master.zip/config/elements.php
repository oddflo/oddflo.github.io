<?php
// rA elements.
return array(
	'Neutral' => 'Neutral',
	'Water' => 'Water',
	'Earth' => 'Earth',
	'Fire' => 'Fire',
	'Wind' => 'Wind',
	'Poison' => 'Poison',
	'Holy' => 'Holy',
	'Dark' => 'Dark',
	'Ghost' => 'Ghost',
	'Undead' => 'Undead'
);
?>
