<?php
// rA monster sizes.
return array(
	 'Small' => 'Small',
	 'Medium' => 'Medium',
	 'Large' => 'Large'
)
?>
