<?php
return array(
	0	=>	// Default class list
	array(
		'class_all' => 'All classes',
		'class_normal' => 'Normal',
		'class_upper' => 'Upper',
		'class_baby' => 'Baby'
	),
	1	=>	// Renewal class list
	array(
		'class_third' => 'Third',
		'class_third_upper' => 'Third Upper',
		'class_third_baby' => 'Third Baby'
	)
)
?>
