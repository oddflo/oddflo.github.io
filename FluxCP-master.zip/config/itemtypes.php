<?php
return array(
	'ammo'			=> 'Ammo',
	'armor'			=> 'Armor',
	'card'			=> 'Card',
	'cash'			=> 'Cash Shop Reward',
	'delayconsume'	=> 'Delay Consume',
	'etc'			=> 'Etc',
	'healing'		=> 'Healing',
	'petarmor'		=> 'Pet Armor',
	'petegg'		=> 'Pet Egg',
	'shadowgear'	=> 'Shadow Equipment',
	'usable'		=> 'Usable',
	'weapon'		=> 'Weapon'
)
?>
