<?php
return array(
	'trade_nodrop'			=> 'Can\'t be dropped',
	'trade_notrade'			=> 'Can\'t be traded with player',
	'trade_tradepartner'	=> 'Can\'t be traded with partner',
	'trade_nosell'			=> 'Can\'t be sold to NPC',
	'trade_nocart'			=> 'Can\'t be put in Cart',
	'trade_nostorage'		=> 'Can\'t be put in Storage',
	'trade_noguildstorage'	=> 'Can\'t be put in Guild Storage',
	'trade_nomail'			=> 'Can\'t be attached in Mail',
	'trade_noauction'		=> 'Can\'t be auctioned'
)
?>
